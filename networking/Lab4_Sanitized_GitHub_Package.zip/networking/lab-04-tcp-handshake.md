# Lab 4 — TCP Three-Way Handshake Investigation

## Objective
Inspect a TCP three-way handshake in Wireshark, verify relative sequence and acknowledgment numbers, and recognize subsequent TLS negotiation.

## Environment
- Apple MacBook M2 running macOS
- Wireshark capture on interface `en0`
- Test connection: `https://example.com`
- TCP destination port: `443` (HTTPS)
- TCP stream: `19`

## Evidence

### 1. Handshake and TLS initiation
![Sanitized Wireshark capture showing packets 1023–1025 and the TLS Client Hello](01_tcp_handshake_sanitized.png)

*Source and destination IP address values were covered with opaque redaction before public sharing. This is a cropped, sanitized screenshot, not a full original capture.*

| Frame | Observed TCP flags | Relative sequence | Relative acknowledgment |
|---|---|---:|---:|
| 1023 | SYN, ECE, CWR | 0 | Not valid (ACK not set) |
| 1024 | SYN, ACK, ECE | 0 | 1 |
| 1025 | ACK | 1 | 1 |

The client initiated a connection from ephemeral port `51301` to destination port `443`. The server replied with SYN-ACK, and the client responded with ACK. A TLS 1.3 Client Hello with SNI `example.com` followed at frame 1026.

### 2. Initial SYN flag inspection
![Sanitized Wireshark TCP flags detail for the initial SYN](02_tcp_flags_sanitized.png)

The initial packet's TCP flag field is `0x0c2`, showing SYN, ECE, and CWR set. The ACK flag is not set. The ECE/CWR combination on an initial SYN is consistent with ECN capability negotiation.

## Timing
- SYN: `50.605780` s
- SYN-ACK: `50.621783` s
- Final ACK: `50.622015` s
- Observed SYN-to-SYN-ACK interval: approximately **16.003 ms** (not a full end-to-end latency measurement).

## Assessment
The capture shows a successful TCP three-way handshake followed by TLS 1.3 negotiation. The reviewed packets do not independently establish malicious activity.

## SOC analyst relevance
- Interpret packet-level TCP flags
- Trace connection establishment
- Correlate sequence and acknowledgment numbers
- Recognize the transition from TCP to TLS
- Document observations and limitations clearly

## Privacy
Screenshots were sanitized before publication. The raw packet capture was not uploaded; original captures may contain private network identifiers and unrelated traffic.
